document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements
    const urlInput = document.getElementById('urlInput');
    const checkButton = document.getElementById('checkButton');
    const loading = document.getElementById('loading');
    const results = document.getElementById('results');
    const error = document.getElementById('error');
    const scoreCircle = document.getElementById('scoreCircle');
    const scoreElement = document.getElementById('score');
    const titleElement = document.getElementById('title');
    const domainElement = document.getElementById('domain');
    const analysisElement = document.getElementById('analysis');

    // Set initial state
    loading.classList.add('hidden');
    results.classList.add('hidden');
    error.classList.add('hidden');

    // Add click handler for check button
    checkButton.addEventListener('click', function() {
        const url = urlInput.value.trim();
        if (!url) {
            showError('Please enter a URL');
            return;
        }
        analyzeArticle(url);
    });

    // Add enter key handler for input
    urlInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            checkButton.click();
        }
    });

    function analyzeArticle(url) {
        // Show loading state
        loading.classList.remove('hidden');
        results.classList.add('hidden');
        error.classList.add('hidden');

        // API endpoint
        const apiUrl = 'http://localhost:5000/analyze';

        // Make API request
        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ url: url })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                throw new Error(data.error);
            }

            // Update UI with results
            scoreElement.textContent = data.score.toFixed(1);
            titleElement.textContent = data.title;
            domainElement.textContent = data.domain;
            
            // Set score circle color
            scoreCircle.className = `w-20 h-20 rounded-full flex items-center justify-center mx-auto text-white text-2xl font-bold bg-${data.color}-500`;
            
            // Generate analysis text
            const analysis = generateAnalysis(data.score);
            analysisElement.textContent = analysis;

            // Show results
            loading.classList.add('hidden');
            results.classList.remove('hidden');
        })
        .catch(error => {
            console.error('Error:', error);
            showError(error.message);
        });
    }

    function generateAnalysis(score) {
        if (score > 70) {
            return "This article appears to be highly credible. It has strong author attribution, proper citations, and consistent information.";
        } else if (score >= 30) {
            return "This article shows good credibility indicators. Consider cross-referencing with other sources for important claims.";
        } else {
            return "Exercise caution with this article. Some credibility indicators are missing or weak. Verify claims with other sources.";
        }
    }

    function showError(message) {
        loading.classList.add('hidden');
        results.classList.add('hidden');
        error.textContent = message || 'Error analyzing article. Please try again.';
        error.classList.remove('hidden');
    }
}); 